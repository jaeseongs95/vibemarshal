from __future__ import annotations

import ast
import enum
import json
import unittest
from pathlib import Path
from unittest.mock import patch


class EnginePythonCompatibilityTests(unittest.TestCase):
    def test_string_enums_preserve_public_contract_without_stdlib_strenum(self) -> None:
        from pydantic import TypeAdapter
        from flowmarshal.engine import domain, qualification_manifest

        # 실제 Engine import와 enum.StrEnum이 없는 분기를 같은 공개 기대값으로 검사한다.
        # AST 분리 검사는 실 Python 3.10 환경 검증을 대신하지 않는다.
        tree = ast.parse(Path(domain.__file__).read_text(encoding="utf-8"))
        enum_nodes = [
            node for node in tree.body
            if (isinstance(node, (ast.ImportFrom, ast.Try)) and any(
                isinstance(child, ast.ImportFrom) and child.module == "enum"
                for child in ast.walk(node)
            )) or (isinstance(node, ast.ClassDef) and any(
                isinstance(base, ast.Name) and base.id == "StrEnum"
                for base in node.bases
            ))
        ]
        fallback_namespace = {"__name__": "engine_enum_compatibility"}
        with patch.dict(enum.__dict__):
            enum.__dict__.pop("StrEnum", None)
            exec(compile(ast.Module(body=enum_nodes, type_ignores=[]), domain.__file__, "exec"),
                 fallback_namespace)

        self.assertIs(qualification_manifest.StrEnum, domain.StrEnum)
        qualification_tree = ast.parse(
            Path(qualification_manifest.__file__).read_text(encoding="utf-8")
        )
        qualification_nodes = [
            node for node in qualification_tree.body
            if (isinstance(node, ast.ImportFrom) and node.module == "enum") or (
                isinstance(node, ast.ClassDef) and any(
                    isinstance(base, ast.Name) and base.id == "StrEnum"
                    for base in node.bases
                )
            )
        ]
        with patch.dict(enum.__dict__):
            enum.__dict__.pop("StrEnum", None)
            exec(compile(ast.Module(body=qualification_nodes, type_ignores=[]),
                         qualification_manifest.__file__, "exec"), fallback_namespace)

        runtime_namespace = vars(domain) | vars(qualification_manifest)
        enum_names = [node.name for node in (*enum_nodes, *qualification_nodes)
                      if isinstance(node, ast.ClassDef)]
        self.assertEqual(
            {name: [(member.name, member.value) for member in runtime_namespace[name]]
             for name in enum_names},
            {name: [(member.name, member.value) for member in fallback_namespace[name]]
             for name in enum_names},
        )

        cases = (
            ("LifecycleStage", "PRODUCTION", "production"),
            ("CandidateStatus", "NEEDS_REVISION", "needs_revision"),
            ("EvidenceKind", "MODEL_REVIEW", "model_review"),
            ("TaskRuntimeStatus", "COMPLETED", "completed"),
            ("RuntimeIntentStatus", "UNKNOWN", "unknown"),
            ("EvidenceProvenance", "FAULT_INJECTED", "fault_injected"),
            ("QualificationCellStatus", "NOT_RUN", "NOT_RUN"),
            ("QualificationFailureClass", "ENVIRONMENT", "environment"),
        )
        for mode, namespace in (("runtime", runtime_namespace), ("fallback", fallback_namespace)):
            for class_name, member_name, expected in cases:
                with self.subTest(mode=mode, enum=class_name):
                    enum_type = namespace[class_name]
                    member = enum_type[member_name]
                    self.assertIsInstance(member, str)
                    self.assertEqual(member.value, expected)
                    self.assertEqual(member, expected)
                    self.assertEqual(str(member), expected)
                    self.assertEqual(format(member, ">20"), expected.rjust(20))
                    self.assertEqual(json.dumps(member), json.dumps(expected))
                    self.assertIs(enum_type(expected), member)
                    self.assertIs(enum_type(member), member)
                    with self.assertRaises(ValueError):
                        enum_type("__invalid_public_value__")
                    adapter = TypeAdapter(enum_type)
                    self.assertEqual(adapter.dump_json(member), json.dumps(expected).encode("utf-8"))
                    self.assertIs(adapter.validate_json(json.dumps(expected)), member)


if __name__ == "__main__":
    unittest.main()
